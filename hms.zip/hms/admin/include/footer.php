<footer>
	<div class="footer-inner">
		<div class="pull-left">
			<span>&copy;VETCOR 2024</span>
			<p style="text-align: center;color: #000;font-weight: 600;"></p>
		</div>
		<div class="pull-right">
			<span class="go-top"><i class="ti-angle-up"></i></span>
		</div>
	</div>
</footer>